package com.example.medicalbookingapp;

import java.sql.Date;
import java.text.SimpleDateFormat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BookingDatabase extends SQLiteOpenHelper{
	private static String DBName2 = "Booking.db";
	private static String TableName = "Patient_Bookings";
	public static String column_ID = "Booking_ID";
	public static String columnUsername = "Customer_username";
	public static String columnMedicalcentre = "MedicalCentres";
	public static String columnDoctor = "DoctorName";
	public static String columnDate = "Booking_Date";
	public static String columnTime = "Booking_Time";
	
	
	 public BookingDatabase(Context context){
	      super(context,DBName2,null,1);
	   }

	 public void onCreate(SQLiteDatabase db) {
			// creates table
			db.execSQL("create table Patient_Bookings"
					+ "(Booking_ID integer,Customer_username text,MedicalCentres text, DoctorName text, Booking_Date text, Booking_Time Text)");

		}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
			//db.execSQL("DROP TABLE IF EXIST Patient_Bookings");
			// onCreate(db);
		}
	
	 
	public void insertBooking(String id,String username, String medicalCentre, String doctorName, String bookingDate, String bookingTime) {

		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues content = new ContentValues();		
		content.put("Booking_ID", id);
		content.put("Customer_username", username);
		content.put("MedicalCentres", medicalCentre);
		content.put("DoctorName", doctorName);
		content.put("Booking_Date",(bookingDate));
		content.put("Booking_Time", (bookingTime));
	 db.insert("Patient_Bookings", null, content);
		/*Check if values are really inserted to our Table or not
		*if result is equal to -1 then it means no new rows inserted in to our table 
		*/
	//	if(result == -1)
		//	return false;
		//else
		//	return true;

	}
	
	public Cursor getBookings(){
		SQLiteDatabase db = this.getWritableDatabase();
		Cursor result= db.rawQuery("select * from " +TableName, null);
		return result;
		
	}
	
}

