package com.example.medicalbookingapp.test;

import org.junit.Test;

import com.example.medicalbookingapp.PatientRegister;
import com.example.medicalbookingapp.R.id;

import android.R;
import android.test.ActivityInstrumentationTestCase2;
import android.widget.EditText;

public class registerTests extends
		ActivityInstrumentationTestCase2<PatientRegister> {
	EditText namein, usernamein, passwordin,age;
	
	
	@SuppressWarnings("deprecation")
	public registerTests() {
		super("com.example.medicalbookingapp",PatientRegister.class);
	}

	protected void setUp() throws Exception {
		super.setUp();
		PatientRegister pr=getActivity();
		
		//gets and assign the elements from activity
		//namein =(EditText)getActivity().findViewById(id.namein);
		usernamein =(EditText)getActivity().findViewById(id.usernamein);
		passwordin =(EditText)getActivity().findViewById(id.passwordin);
		
	}
	
	@Test
	public void testvalidage(){
		//namein =(EditText)getActivity().findViewById(id.namein);
		//namein.setText("");
		//assertEquals("","");	
	}
	
	@Test
	public void testemptyname(){
		//namein =(EditText)getActivity().findViewById(id.namein);
		//namein.setText("");
		//assertEquals("","");	
	}
	
	@Test
	public void testemptydetails(){
		namein =(EditText)getActivity().findViewById(id.namein);
		namein.append("");
		assertFalse(namein.isActivated());	
	}
	
	
	
	

}
