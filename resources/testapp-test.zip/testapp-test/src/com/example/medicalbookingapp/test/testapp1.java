package com.example.medicalbookingapp.test;

import junit.framework.TestCase;

public class testapp1 extends TestCase {

	public testapp1(String name) {
		super(name);
	}

	public void testRunTest() {
		//fail("Not yet implemented");
	}

	public void testSetUp() {
		//fail("Not yet implemented");
	}

	public void testGetActivity() {
		//fail("Not yet implemented");
	}

	public void testGetName() {
		//fail("Not yet implemented");
	}

	public void testSetName() {
		//fail("Not yet implemented");
	}

}
