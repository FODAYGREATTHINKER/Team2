package com.example.medicalbookingapp.test;

import org.junit.Test;

import com.example.medicalbookingapp.PatientRegister;

import android.test.ActivityInstrumentationTestCase2;

public class registertest extends ActivityInstrumentationTestCase2<PatientRegister>{

	public registertest(Class<PatientRegister> activityClass) {
		super(activityClass);
	}

	public registertest() {
	    super(PatientRegister.class);
	}
	
	protected void setUp() throws Exception {
		super.setUp();
	}

	@Test
	public void testgetname(){
		
	}
}
