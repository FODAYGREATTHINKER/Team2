package com.example.medicalbookingapp;

import java.util.HashMap;

public class Database {

	 HashMap hm=new HashMap();

	    private static Database instance = new Database();

	    //make the constructor private so that this class cannot be
	    //instantiated
	    private Database(){}

	    //Get the only object available
	    public static Database getInstance(){
	        return instance;
	    }
}
