package com.example.medicalbookingapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Home extends Activity {

	TextView wname;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		wname = (TextView) findViewById(R.id.wname);
		
		
		
		
		
		Database object = Database.getInstance();
		
		//just for now need to be changed and need a database
		for (Object key : object.hm.keySet()) {
			String username=(String) key;
			wname.setText(username);
		}
		
		
	}
}
