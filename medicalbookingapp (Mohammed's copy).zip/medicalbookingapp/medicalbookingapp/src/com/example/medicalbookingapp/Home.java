
package com.example.medicalbookingapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;

public class Home extends Activity {
    // variable declaration from user welcome text
    TextView wname;
    Button b;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        wname = (TextView) findViewById(R.id.wname);

        // Button that links pages with booking page.
        Button b = (Button) findViewById(R.id.button1);
        b.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(Home.this, BookingPage.class);
                startActivity(Intent);

            }

        });
        
        Button logout = (Button) findViewById(R.id.logoutBtn);
        logout.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),
                        MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                
            }
            
        });
        
        Button view = (Button) findViewById(R.id.viewBtn);
        view.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), viewBookings.class);
                startActivity(intent);
            }
        
        });
        
        // gets username with intent from main when login sucessfull
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String value = extras.getString("username");
            wname.setText(value);
            // username entered to this method so it will can be used to get the
            // username of user
            getusername(value);

        }

    }

    // this method can be used for getting username for other methods
    public String getusername(String username) {
        return username;
    }

}