package com.example.medicalbookingapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

public class viewBookings extends Activity {
	BookingDatabase bd;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewbookings);
		bd = new BookingDatabase(this);
		view();
	}

	public void view() {
		Cursor view = bd.getBookings();
		if (view.getCount() == 0) {
			message("Error", "Nothing Found");
			
			return;
		}

		StringBuffer buffer = new StringBuffer();
		while (view.moveToNext()) {
			buffer.append("Id: " + view.getString(0) + "\n");
			buffer.append("Username: " + view.getString(1) + "\n");
			buffer.append("MedicalCentres: " + view.getString(2) + "\n");
			buffer.append("Doctor: " + view.getString(3) + "\n");
			buffer.append("BookingDate: " + view.getString(4) + "\n");
			buffer.append("BookingTime: " + view.getString(5) + "\n");
		}
		
		message("Data", buffer.toString());

	}

	public void message(String message, String msg) {
		AlertDialog.Builder build = new AlertDialog.Builder(this);
		build.setCancelable(true);
		build.setTitle(message);
		build.setMessage(msg);
		build.show();
	}
}
